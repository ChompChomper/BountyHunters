using Godot;
using System;

public partial class Backside : Sprite2D
{
    public override async void _Ready()
    {
        Vector2 originalPos = Position;

        // Wait 3 seconds
        await ToSignal(GetTree().CreateTimer(3f), "timeout");

        Vector2 target = originalPos + new Vector2(0, 150);
        float duration = 0.5f;
        float time = 0f;

        while (time < duration)
        {
            float t = time / duration;
            Position = originalPos.Lerp(target, t);
            await ToSignal(GetTree().CreateTimer(0.01f), "timeout");
            time += 0.01f;
        }
    }
}
