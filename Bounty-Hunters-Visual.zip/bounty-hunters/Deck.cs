using Godot;
using System;

public partial class Deck : Sprite2D
{
    public override async void _Ready()
    {
        Vector2 originalPos = Position;
        Random rand = new Random();

        // Stronger and longer shake
        for (int i = 0; i < 20; i++)
        {
            Vector2 shake = new Vector2(
                (float)(rand.NextDouble() * 20 - 10),  // Stronger shake
                (float)(rand.NextDouble() * 20 - 10)
            );
            Position = originalPos + shake;
            await ToSignal(GetTree().CreateTimer(0.05f), "timeout");
        }

        Position = originalPos;

        // Move to the left (450 pixels)
        Vector2 target = originalPos - new Vector2(450, 0);
        float duration = 0.5f;
        float time = 0f;

        while (time < duration)
        {
            float t = time / duration;
            Position = originalPos.Lerp(target, t);
            await ToSignal(GetTree().CreateTimer(0.01f), "timeout");
            time += 0.01f;
        }

        Position = target;
    }
}
