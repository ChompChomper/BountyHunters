using Godot;
using System;

public partial class FirstCard : Sprite2D
{
    public override async void _Ready()
    {
        Vector2 originalPos = Position;

        // Wait 5 seconds
        await ToSignal(GetTree().CreateTimer(5f), "timeout");

        Vector2 target = originalPos + new Vector2(150, 310);
        float duration = 0.2f;
        float time = 0f;

        while (time < duration)
        {
            float t = time / duration;
            Position = originalPos.Lerp(target, t);
            await ToSignal(GetTree().CreateTimer(0.01f), "timeout");
            time += 0.01f;
        }

        GameManager gm = GetTree().CurrentScene as GameManager;

        if (gm != null)
        {
            gm.DamageMe(1);
        }
        else
        {
            GD.Print("GameManager not found or cast failed.");
        }
    }   
}
