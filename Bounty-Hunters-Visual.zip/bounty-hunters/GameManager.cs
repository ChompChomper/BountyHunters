using Godot;
using System;
using System.Collections.Generic;

public partial class GameManager : Node2D
{
	bool isPlayerTurn;

	private List<string> deck = new List<string>()
	{
		"Explosion - ATTACK (2x Block or 2x Damage)",
		"Heart Attack - ATTACK (either Block/Dodge or 2x Damage)",
		"Weapons Sabotage - ATTACK (Discard an attack or 2x Damage)",
		"Weapons Sabotage - ATTACK (Discard an attack or 2x Damage)",
		"Revenge - ATTACK you can only play this if you took any damage after your last turn this showdown (either 2 Block/2 dodge or 3 Damage)",
		"Just better - ATTACK (1 Damage)",
		"Get Serious - ATTACK (either 2x Dodge/Discard a trick or 2x Damage)",
		"Steal - ATTACK (Dodge or steal a card)",
		"Blunt Force - ATTACK (Block or 1 Damage, stun)",
		"Exploit - ATTACK (Dodge or Draw 2 cards)",
		"Quick Draw - ATTACK (Dodge or 1 Damage, draw a card)",
		"Bite - ATTACK (Dodge or 1 Damage, heal 1 hp)",
		"Rush - ATTACK (Block or 1 Damage) if this attack is blocked, draw a card",
		"Papercut - ATTACK (Block or 1 damage, discard one of your target's cards)",
		"Unspring - ATTACK (Either 2x Block/Discard a trap or 2 Damage)",

		"Speedster - DEFENSE (2x Dodge)",
		"Speedster - DEFENSE (2x Dodge)",
		"Blocker - DEFENSE (2x Block)",
		"Blocker - DEFENSE (2x Block)",
		"Flee - DEFENSE (Dodge) Draw a card",
		"Flee - DEFENSE (Block) discard one of your target's cards",
		"Flexible - DEFENSE (Dodge AND Block)",
		"Specialist - DEFENSE (2x Dodge or 2x Block)",

		"Cut/Dodge - ATTACK/DEFENSE Play either as (Dodge or 1 damage) or (Dodge)",
		"Cut/Dodge - ATTACK/DEFENSE Play either as (Dodge or 1 damage) or (Dodge)",

		"Stab/Block - ATTACK/DEFENSE Play either as (Block or 1 Block) or (Block)",
		"Stab/Block - ATTACK/DEFENSE Play either as (Block or 1 Block) or (Block)",
		
		"Catchup mechanic - TRICK (Deal 1 damage to the highest hp player, heal the lowest hp player by 1. this card can't be played if there is a Hp tie on the lowest or the highest hp spot.)",
		"Snowstorm - TRICK (Every enemy must discard one of the cards they own. put this on top of the deck)",
		"Disrupt - TRICK (Discard any card)",
		"Disrupt - TRICK (Discard any card)",
		"Salvage - TRICK (Draw the last played card)",
		"Salvage - TRICK (Draw the last played card)",

		"HP Potion - TRICK (Heal any player 1 hp)",
		"HP Potion - TRICK (Heal any player 1 hp)"
	};

	private List<string> playerHand = new List<string>()
	{
		//empty until cards added
	};

	private List<string> opponentHand = new List<string>()
	{
		//empty until cards added
	};

	public void DrawCard(string player)
	{
		Random rd = new Random();
		int cardDrawn = rd.Next(0, deck.Count);

		if (player == "player"){
			playerHand.Add(deck[cardDrawn]);
            GD.Print("card drawn: "+deck[cardDrawn]);
		}else{
			opponentHand.Add(deck[cardDrawn]);
            GD.Print("card drawn BY OPPONENT: "+deck[cardDrawn]);
		}

		deck.RemoveAt(cardDrawn);
	}

    public void PlayCard(string card)
    {
        GD.Print("Write the name of the card you want to play: ");
        //bool trueInList = list.Contains(true);
    }

	public void ChangeTurn()
	{
		isPlayerTurn = !isPlayerTurn;
		if (isPlayerTurn == true){
			GD.Print("It is now your turn.");
		}else{
			GD.Print("It is now the opponent's turn.");
		}
	}

	public override void _Ready()
	{
		Random rd = new Random();

		/*foreach (string item in deck)
		{
			GD.Print(item);
		}*/

        for(int i = 0; i < 6; i++){
            DrawCard("player");
        }
		for(int i = 0; i < 6; i++){
            DrawCard("opp");
        }

        isPlayerTurn = Convert.ToBoolean(rd.Next(0, 2));

        //PlayCard();

		ChangeTurn();

        //line_edit.text_submitted.connect();
	}
	
	public void DamageMe(int amount)
    {
        Label label = GetNode<Label>("MyHP/MyNum"); // path relative to root node
        if (label == null)
        {
            GD.Print("Label node not found!");
            return;
        }

		if (int.TryParse(label.Text, out int number))
		{
			number -= amount;
			label.Text = number.ToString();
			if (number < 1)
			{
				GD.Print("You lose !");
			}
        }
		else
		{
			GD.Print("Label text is not a valid number!");
		}
    }

	public void DamageOpp(int amount)
    {
        Label label = GetNode<Label>("OppHP/OppNum"); // path relative to root node
        if (label == null)
        {
            GD.Print("Label node not found!");
            return;
        }

		if (int.TryParse(label.Text, out int number))
		{
			number -= amount;
			label.Text = number.ToString();
			if (number < 1)
			{
				GD.Print("You Win !");
			}
        }
		else
		{
			GD.Print("Label text is not a valid number!");
		}
    }

	public override void _Process(double delta)
	{

	}
}
