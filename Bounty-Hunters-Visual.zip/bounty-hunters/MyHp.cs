using Godot;
using System;

public partial class MyHp : Sprite2D
{
    /*public override async void _Ready()
    {
        GD.Print("My path: " + GetPath());
        GD.Print("Parent children:");
        foreach (Node child in GetParent().GetChildren())
        {
            GD.Print(child.Name);
        }
    }*/
}
