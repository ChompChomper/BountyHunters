using Godot;
using System;

public partial class Sprite2d : Sprite2D
{
}
