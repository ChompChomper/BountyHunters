using Godot;
using System;
using System.Collections.Generic;

public partial class GameManager : Node2D
{
	bool isPlayerTurn;

	private List<string> deck = new List<string>()
	{
		"card1",
		"card2",
		"card3",
		"card4",
		"card5",
		"card6",
		"card7",
		"card8",
        "card9",
        "card10"
	};

	private List<string> playerHand = new List<string>()
	{
		//empty until cards added
	};

	private List<string> opponentHand = new List<string>()
	{
		//empty until cards added
	};

	public void DrawCard(string player)
	{
		Random rd = new Random();
		int cardDrawn = rd.Next(0, deck.Count);

		if (player == "player"){
			playerHand.Add(deck[cardDrawn]);
            GD.Print("card drawn: "+deck[cardDrawn]);
		}else{
			opponentHand.Add(deck[cardDrawn]);
            GD.Print("card drawn BY OPPONENT: "+deck[cardDrawn]);
		}

		deck.RemoveAt(cardDrawn);
	}

    public void PlayCard(string card)
    {
        GD.Print("Write the name of the card you want to play: ");
        //bool trueInList = list.Contains(true);
    }

	public void ChangeTurn()
	{
		isPlayerTurn = !isPlayerTurn;
		if (isPlayerTurn == true){
			GD.Print("It is now your turn.");
		}else{
			GD.Print("It is now the opponent's turn.");
		}
	}

	public override void _Ready()
	{
		Random rd = new Random();

		/*foreach (string item in deck)
		{
			GD.Print(item);
		}*/

        for(int i = 0; i < 4; i++){
            DrawCard("player");
            DrawCard("opp");
        }

        isPlayerTurn = Convert.ToBoolean(rd.Next(0, 2));

        //PlayCard();

		ChangeTurn();

        //line_edit.text_submitted.connect();
	}

	public override void _Process(double delta)
	{
		
	}
}
